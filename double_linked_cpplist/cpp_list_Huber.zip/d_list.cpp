#include "d_list.hpp"
#include <stdio.h>
#include <stdlib.h>


List::List() {
    first = nullptr;
    last = nullptr;
}

bool List::get(unsigned int index, int& val) {
    ListNode* node = first;
    if(node == nullptr){
        return false;
    }
    for (int i = 0; i < index; i++) {
        if (node == nullptr) {
            return false;
        }
        node = node->next;
    }
    val = node->value;
    return true;
}

void List::push_back(int value) {
    ListNode* node = first;
    if (node == nullptr) {
        //ListNode* newNode = (ListNode*)malloc(sizeof(ListNode));
        ListNode* newNode = new ListNode;
        if (newNode == nullptr) {
            exit(1);
        }
        newNode->value = value;
        newNode->next = nullptr;
        newNode->prev = nullptr;
        first = newNode;
        last = newNode;
        return;
    }
    node = last;
    //ListNode* newNode = (ListNode*)malloc(sizeof(ListNode));
    ListNode* newNode = new ListNode;
    if (newNode == nullptr) {
        exit(1);
    }
    newNode->value = value;
    newNode->next = nullptr;
    node->next = newNode;
    newNode->prev = node;
    last = newNode;
    return;
}

List::~List() {
    while(length() > 0) {
        remove(0);
    }
}

void List::remove(unsigned int index){
    ListNode* node = first;
    if (first == nullptr) {
        return;
    }
    ListNode* tmp;
    if(index == 0) {
        first = node->next;
        if(first != nullptr)
            first->prev = nullptr;
        else{
            last = nullptr;
        }
        //free(node); node = nullptr;
        delete node; node = nullptr;
        return;
    }
    else if (index == length() - 1) {
        node = last;
        last = node->prev;
        node->prev->next = nullptr;
        //free(node); node = NULL;
        delete node; node = nullptr;
        return;
    }
    for (int i = 0; i < index - 1; i++) {
        node = node->next;
        if (node->next == nullptr) {
            return;
        }
    }
    tmp = node->next;
    node->next = tmp->next;
    tmp->next->prev = node;
    //free(tmp); tmp = NULL;
    delete tmp; tmp = nullptr;
    return;
}

void List::print(){
    ListNode* curr = first;
    if(curr == nullptr){
        return;
    }
    if(curr->next == nullptr){
        printf("%i\n", curr->value);
        return;
    }
    while(curr != nullptr){
        printf("%i ", curr->value);
        curr = curr->next;
    }
}

void List::printReversed(){
        ListNode* curr = last;
    if(curr == nullptr){
        return;
    }
    if(curr->prev == nullptr){
        printf("%i\n", curr->value);
        return;
    }
    while(curr != nullptr){
        printf("%i ", curr->value);
        curr = curr->prev;
    }
}

unsigned int List::length() {
    unsigned int len = 0;
    for (ListNode* i = first; i != nullptr; i = i->next) {
        len++;
    }
    return len;
}